#ifndef HELPER_METHODS
#define HELPER_METHODS
void printConsoleMenu(bool testMode);
#endif // HELPER_METHODS
