#ifndef GRAPHICS
#define GRAPHICS

void initGraphicsWindow();

#endif // GRAPHICS

