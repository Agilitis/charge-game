#ifndef CONSTANTS
#define CONSTANTS

char LOGO[8][200];
const int WINDOW_WIDTH;
const int WINDOW_HEIGHT;
const int MAIN_CHARGE_RADIUS;
const int PENALTY;


#endif // CONSTANTS
